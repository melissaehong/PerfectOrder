//
//  GalleryImage.m
//  Fire Island
//
//  Created by Peter Rocker on 19/06/2015.
//  Copyright (c) 2015 Motive Interactive. All rights reserved.
//

#import "GalleryImage.h"


@implementation GalleryImage

@dynamic category;
@dynamic imageId;
@dynamic name;
@dynamic miniUrl;
@dynamic imageUrl;

@end
