//
//  PhotoUploadViewController.h
//  Fire Island
//
//  Created by Peter Rocker on 22/06/2015.
//  Copyright (c) 2015 Motive Interactive. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PhotoUploadViewController : UIViewController

@property (nonatomic, strong) UIImage* imageToSend;

@end
