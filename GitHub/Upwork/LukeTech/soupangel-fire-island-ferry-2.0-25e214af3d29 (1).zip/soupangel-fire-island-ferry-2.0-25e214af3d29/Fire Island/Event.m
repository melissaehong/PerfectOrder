//
//  Event.m
//  Fire Island
//
//  Created by Peter Rocker on 23/06/2015.
//  Copyright (c) 2015 Motive Interactive. All rights reserved.
//

#import "Event.h"


@implementation Event

@dynamic eventId;
@dynamic eventTitle;
@dynamic eventDescription;
@dynamic eventLocation;
@dynamic eventLinkout;
@dynamic eventStartDate;
@dynamic eventStartTime;
@dynamic eventEndDate;
@dynamic eventEndTime;

@end
