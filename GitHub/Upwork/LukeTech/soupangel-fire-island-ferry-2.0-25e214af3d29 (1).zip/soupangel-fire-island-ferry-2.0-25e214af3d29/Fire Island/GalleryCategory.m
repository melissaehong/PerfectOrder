//
//  GalleryCategory.m
//  Fire Island
//
//  Created by Peter Rocker on 19/06/2015.
//  Copyright (c) 2015 Motive Interactive. All rights reserved.
//

#import "GalleryCategory.h"


@implementation GalleryCategory

@dynamic galleryId;
@dynamic name;

@end
