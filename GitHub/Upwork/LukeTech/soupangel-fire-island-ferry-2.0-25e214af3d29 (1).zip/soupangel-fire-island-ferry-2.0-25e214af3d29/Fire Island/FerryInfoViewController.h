//
//  SecondViewController.h
//  Fire Island
//
//  Created by Peter Rocker on 16/06/2015.
//  Copyright (c) 2015 Motive Interactive. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FerryInfoViewController : UIViewController


@end

